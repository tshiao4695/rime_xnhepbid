with open('PBYB.txt', 'r', encoding='utf-8') as file:
    # 逐行读取文件内容
    lines = file.readlines()

# 遍历每一行数据
for i in range(len(lines)):
    # 使用 tab 分割第一列、第二列和后续列（忽略第三列及其后的数据）
    parts = lines[i].strip().split('\t')

    # 检查列的数量是否至少为2，如果不是，跳过该行
    if len(parts) < 2:
        continue
    
    # 对第二列进行处理
    col_data = parts[1]

    # 判断是否只有一个英文字母
    if len(col_data) == 1:
        # 将单个字母双写
        col_data *= 2

    # 更新第二列数据
    parts[1] = col_data

    # 更新行数据，只保留前两列
    lines[i] = '\t'.join(parts[:2]) + '\n'

# 将处理后的数据写回文件
with open('output.txt', 'w', encoding='utf-8') as output_file:
    output_file.writelines(lines)
